//
//  TRDetailsViewController.swift
//  TRWeatherAPI
//
//  Created by Focaloid on 02/02/17.
//  Copyright © 2017 Focaloid. All rights reserved.
//

import UIKit

class TRDetailsViewController: UIViewController {
    
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var descLabel: UILabel!
    @IBOutlet weak var tempLabel: UILabel!
    
    var city : String? = ""
    var desc : String? = ""
    var temp : String? = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named:"ic_bg")!)
        cityLabel.text = city
        descLabel.text = desc
        tempLabel.text = temp
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
