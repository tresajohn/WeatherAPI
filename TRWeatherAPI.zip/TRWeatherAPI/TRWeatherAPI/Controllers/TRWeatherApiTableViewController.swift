//
//  TRWeatherApiTableViewController.swift
//  TRWeatherAPI
//
//  Created by Focaloid on 02/02/17.
//  Copyright © 2017 Focaloid. All rights reserved.
//

import UIKit

class TRWeatherApiTableViewController: UITableViewController,UISearchBarDelegate{

    @IBOutlet weak var weatherSearchBar: UISearchBar!
    @IBOutlet weak var weatherIcon: UIImageView!
    @IBOutlet weak var cityNameLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var dtLabel: UILabel!
    @IBOutlet weak var codLabel: UILabel!
    @IBOutlet weak var celsiusLabel: UILabel!
    @IBOutlet weak var fahrenheitLabel: UILabel!
    @IBOutlet weak var cityTableCell: UITableViewCell!
    @IBOutlet weak var descTableCell: UITableViewCell!
    @IBOutlet weak var tempTableCell: UITableViewCell!
    
    //Variable Declaration
    var searchContent : String?

    enum weatherSetting : String
    {
        case baseUrl = "http://api.openweathermap.org/data/2.5/weather"
        case api = "4e63f48bb2d090d7fb7d80f6447ace6a"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "WEATHER"
        weatherSearchBar.delegate = self
        self.view.backgroundColor = UIColor(patternImage: UIImage(named:"ic_bg")!)
    }
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        searchContent = searchBar.text!
        if (searchContent == nil)
        {
            searchBar.text = "Enter value"
        }
        else{
         getWeather()
        }
    }
    
    func getWeather(){
        let weatherUrlString = weatherSetting.baseUrl.rawValue + "?q=\(searchContent!)&appid=" + weatherSetting.api.rawValue
        let weatherUrl = NSURL(string: weatherUrlString)
        let requestUrl : NSURLRequest = NSURLRequest(URL: weatherUrl!)
        let task = NSURLSession.sharedSession().dataTaskWithRequest(requestUrl){(data,response,error) in
            do{
               let responseDictionary = try! NSJSONSerialization.JSONObjectWithData(data!, options: []) as! NSDictionary
                dispatch_async(dispatch_get_main_queue(),{
                    if let city = responseDictionary["name"] as? String
                    {
                        self.cityNameLabel.text = city
                    }
                    if let weatherDescription = responseDictionary["weather"]![0] as? [String : AnyObject]
                    {
                        self.descriptionLabel.text = weatherDescription["description"] as? String
                    }
                    if let main = responseDictionary["main"] as? [String: AnyObject]
                    {
                        self.temperatureLabel.text = String(main["temp"]!)
                    }
                    if let dt = responseDictionary["dt"] as? Double
                    {
                        self.dtLabel.text = String(dt)
                    }
                    if let cod = responseDictionary["cod"] as? Int
                    {
                        self.codLabel.text = String(cod)
                    }
                    if let imageIcon = responseDictionary["weather"]![0] as? [String:AnyObject]
                    {
                        let icon = imageIcon["icon"] as! String
                        if let iconUrl = NSURL(string: "http://api.openweathermap.org/img/w/\(icon)")
                        {
                            print(iconUrl)
                            if let data = NSData(contentsOfURL: iconUrl)
                            {
                                self.weatherIcon.image = UIImage(data: data)
                            }
                        }
                    }
                })
                
            }
            catch{
                print(error)
            }
        }
        task.resume()
    }
    
    @IBAction func temperatureSwitch(sender: UISwitch) {
        if sender.on{
            celsiusLabel.hidden = true
            fahrenheitLabel.hidden = false
            let temp = temperatureLabel.text
            temperatureLabel.text = String(format: "%.2f", round((Double(temp!)!*1.8)+32))
        }
        else{
            celsiusLabel.hidden = false
            fahrenheitLabel.hidden = true
            let temp = temperatureLabel.text
            temperatureLabel.text = String(format: "%.2f", (Double(temp!)! - 32)/1.8)
        }
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let selectedCell:UITableViewCell = tableView.cellForRowAtIndexPath(indexPath)!
        selectedCell.contentView.backgroundColor = UIColor.clearColor()

        let destination = storyboard?.instantiateViewControllerWithIdentifier("TRDetailsViewController") as? TRDetailsViewController
         navigationController?.pushViewController(destination!, animated: true)
        destination!.city = self.cityNameLabel.text
        destination?.desc = self.descriptionLabel.text
        destination?.temp = self.temperatureLabel.text
    }
    
//    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
//        if  segue.identifier == "segueIdentifier"
//        {
//            let destination = segue.destinationViewController as? TRDetailsViewController
//            destination?.city = cityNameLabel.text
//            destination?.desc = descriptionLabel.text
//            destination?.temp = temperatureLabel.text
//        }
//    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}
